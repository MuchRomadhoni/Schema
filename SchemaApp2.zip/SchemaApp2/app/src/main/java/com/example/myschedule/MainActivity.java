package com.example.myschedule;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button daftar;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = findViewById(R.id.buttonMasuk);
        daftar = findViewById(R.id.button_Daftar);
        daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View n) {

                Intent callDaftar = new Intent(MainActivity.this,register.class);
                startActivity(callDaftar);

            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View n) {

                Intent callLogin = new Intent(MainActivity.this,activity_dashboard.class);
                startActivity(callLogin);

            }
        });
    }
}
